import telebot

API_TOKEN = '7689084982:AAGH5H1X7yJYmS59EieMO_Kq_SK3GLFEX2w'
bot = telebot.TeleBot(API_TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "🤖 Bot is now connected and working!")

bot.polling()